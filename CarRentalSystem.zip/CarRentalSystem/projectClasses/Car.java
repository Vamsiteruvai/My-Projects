package projectClasses;

public class Car {
	public int id;
	public String brand;
	public double price;
	public String colour;
	public String model;
	public String mileage;
	public int seating_capacity;
}
