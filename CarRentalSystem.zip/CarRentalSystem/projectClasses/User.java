package projectClasses;

public class User {
	public String firstName;
	public String lastName;
	public String phone;
	public String email;
	public String adhaar;
	public String address;
	public String designation;
}
