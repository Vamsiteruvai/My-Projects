
import projectGUI.LoginGUI;

public class start {

	public static void main(String[] args) {
		new LoginGUI();
		System.out.print("Project Started Successfully");
	}

}
